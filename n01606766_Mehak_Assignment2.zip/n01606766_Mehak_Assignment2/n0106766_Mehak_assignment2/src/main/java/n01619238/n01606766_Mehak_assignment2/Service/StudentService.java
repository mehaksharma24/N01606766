package n01619238.n01619238_patel_assignment2.Service;

import n01619238.n01619238_patel_assignment2.Model.Student;
import n01619238.n01619238_patel_assignment2.Repository.EnrollmentRepository;
import n01619238.n01619238_patel_assignment2.Repository.StudentRepository;
import n01619238.n01619238_patel_assignment2.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private EnrollmentRepository enrollmentRepository;

    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }
    public Student findByUserID(Long userID) {
        return studentRepository.findByUserId(userID).orElse(null);
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudentById(Long id) {
        return studentRepository.findById(id).orElse(null);
    }
    public void updateStudent(Student student) {
        studentRepository.save(student);
    }
    public void deleteStudentById(Long id) {
        Student student = studentRepository.findById(id).orElse(null);
        if (student != null) {
            enrollmentRepository.deleteByStudentId(student.getId());
            studentRepository.delete(student);
            userRepository.delete(student.getUser());

        }
    }
}
