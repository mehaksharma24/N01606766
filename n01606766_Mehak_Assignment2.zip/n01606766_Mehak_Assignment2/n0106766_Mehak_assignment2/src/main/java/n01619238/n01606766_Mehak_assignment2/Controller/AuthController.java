package n01619238.n01619238_patel_assignment2.Controller;


import n01619238.n01619238_patel_assignment2.Model.User;
import n01619238.n01619238_patel_assignment2.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {
    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, Model model, HttpSession session) {
        User user = userService.findByUsername(username);
        System.out.println("success username");
        if (user != null && user.getPassword().equals(password)) {
            System.out.println("success password");
            session.setAttribute("loggedInUserId", user.getId());
            System.out.println(session.getAttribute("loggedInUserId"));
            if (user.getRole().equals("admin")) {
                return "redirect:/admin/dashboard";
            } else {
                return "redirect:/student/dashboard";
            }
        }
        model.addAttribute("error", "Invalid username or password");
        return "login";
    }
}