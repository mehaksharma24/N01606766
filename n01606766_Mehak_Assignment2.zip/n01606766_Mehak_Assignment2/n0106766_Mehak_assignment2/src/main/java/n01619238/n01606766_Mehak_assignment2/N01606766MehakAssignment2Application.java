package n01619238.n01619238_patel_assignment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class N01619238PatelAssignment2Application {

    public static void main(String[] args) {
        SpringApplication.run(N01619238PatelAssignment2Application.class, args);
    }

}
