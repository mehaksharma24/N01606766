package n01619238.n01619238_patel_assignment2.Repository;

import  n01619238.n01619238_patel_assignment2.Model.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    List<Enrollment> findByStudentIdAndDroppedAtIsNull(Long studentId);
    List<Enrollment> findByStudentId(Long studentId);
    @Modifying
    @Transactional
    void deleteByStudentId(Long studentId);
}
