package n01619238.n01619238_patel_assignment2.Service;

import n01619238.n01619238_patel_assignment2.Model.User;
import n01619238.n01619238_patel_assignment2.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User findByUsername(String username) {
        return userRepository.findByUsername(username).orElse(null);
    }

    public User saveUser(User user) {
        return userRepository.save(user);
    }

//    public List<User> getAllUsers() {
//        return userRepository.findAll();
//    }
}