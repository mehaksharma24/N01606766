package n01619238.n01619238_patel_assignment2.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import n01619238.n01619238_patel_assignment2.Model.Course;

public interface CourseRepository extends JpaRepository<Course, Long> {
}