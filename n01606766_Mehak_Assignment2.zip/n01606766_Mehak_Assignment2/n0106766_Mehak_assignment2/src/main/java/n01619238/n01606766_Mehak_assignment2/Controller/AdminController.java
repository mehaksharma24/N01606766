package n01619238.n01619238_patel_assignment2.Controller;

import n01619238.n01619238_patel_assignment2.Model.*;
import n01619238.n01619238_patel_assignment2.Service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.SecureRandom;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private StudentService studentService;

    @Autowired
    private UserService userService;

    @Autowired
    private EnrollmentService enrollmentService;

    // Check if the user is logged in
    private boolean isLoggedIn(HttpSession session) {
        return session.getAttribute("loggedInUserId") != null;
    }

    // View all students
    @GetMapping("/dashboard")
    public String adminDashboard(Model model, HttpSession session) {
        if (!isLoggedIn(session)) {
            return "redirect:/login"; // Redirect to login if not logged in
        }

        model.addAttribute("students", studentService.getAllStudents());
        return "admin/dashboard";
    }

    // Show form to create a new student
    @GetMapping("/create-student")
    public String createStudentForm(Model model, HttpSession session) {
        if (!isLoggedIn(session)) {
            return "redirect:/login"; // Redirect to login if not logged in
        }

        model.addAttribute("student", new Student());
        return "admin/create-student";
    }

    // Save a new student
    @PostMapping("/create-student")
    public String createStudent(@ModelAttribute Student student, HttpSession session, RedirectAttributes redirectAttributes) {
        if (!isLoggedIn(session)) {
            return "redirect:/login"; // Redirect to login if not logged in
        }
        String password = generateRandomPassword(4);
        User user = new User();
        user.setUsername(student.getEmail());
        user.setPassword(password);
        user.setRole("student");
        userService.saveUser(user);

        student.setUser(user);
        studentService.saveStudent(student);

        redirectAttributes.addFlashAttribute("successMessage", "Student created successfully! Password: " + password);

        return "redirect:/admin/dashboard";
    }
    private String generateRandomPassword(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#$%&*!";
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder();

        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            password.append(characters.charAt(index));
        }

        return password.toString();
    }
    // Show form to edit a student
    @GetMapping("/edit-student/{id}")
    public String editStudentForm(@PathVariable Long id, Model model, HttpSession session) {
        if (!isLoggedIn(session)) {
            return "redirect:/login"; // Redirect to login if not logged in
        }

        Student student = studentService.getStudentById(id);
        if (student != null) {
            model.addAttribute("student", student);
            return "admin/edit-student";
        }
        return "redirect:/admin/dashboard";
    }

    // Update a student
    @PostMapping("/update-student/{id}")
    public String updateStudent(@PathVariable Long id, @ModelAttribute Student student, HttpSession session) {
        if (!isLoggedIn(session)) {
            return "redirect:/login"; // Redirect to login if not logged in
        }

        Student existingStudent = studentService.getStudentById(id);
        if (existingStudent != null) {
            existingStudent.setName(student.getName());
            existingStudent.setEmail(student.getEmail());
            studentService.saveStudent(existingStudent);
        }
        return "redirect:/admin/dashboard";
    }

    // Delete a student
    @GetMapping("/delete-student/{id}")
    public String deleteStudent(@PathVariable Long id, HttpSession session) {
        if (!isLoggedIn(session)) {
            return "redirect:/login"; // Redirect to login if not logged in
        }

        studentService.deleteStudentById(id);
        return "redirect:/admin/dashboard";
    }

    // View a si ngle student's details
    @GetMapping("/view-student/{id}")
    public String viewStudent(@PathVariable Long id, Model model, HttpSession session) {
        if (!isLoggedIn(session)) {
            return "redirect:/login"; // Redirect to login if not logged in
        }

        Student student = studentService.getStudentById(id);
        if (student != null) {
            // Fetch the student's enrollment history
            List<Enrollment> enrollments = enrollmentService.getEnrollmentsByStudentId(student.getId());

            model.addAttribute("student", student);
            model.addAttribute("enrollments", enrollments);
            return "admin/view-student";
        }
        return "redirect:/admin/dashboard";
    }
}