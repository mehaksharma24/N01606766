package n01619238.n01619238_patel_assignment2.Service;

import n01619238.n01619238_patel_assignment2.Model.Enrollment;
import n01619238.n01619238_patel_assignment2.Model.Student;
import n01619238.n01619238_patel_assignment2.Model.Course;
import n01619238.n01619238_patel_assignment2.Repository.EnrollmentRepository;
import n01619238.n01619238_patel_assignment2.Repository.StudentRepository;
import n01619238.n01619238_patel_assignment2.Repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class EnrollmentService {
    @Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CourseRepository courseRepository;

    public Enrollment enrollStudent(Long studentId, Long courseId) {
        // Fetch the student and course entities
        Student student = studentRepository.findById(studentId).orElse(null);
        Course course = courseRepository.findById(courseId).orElse(null);

        if (student != null && course != null) {
            // Create a new enrollment
            Enrollment enrollment = new Enrollment();
            enrollment.setStudent(student); // Set the Student object
            enrollment.setCourse(course);   // Set the Course object
            enrollment.setEnrolledAt(LocalDateTime.now());
            return enrollmentRepository.save(enrollment);
        }
        return null; // Return null if student or course is not found
    }

    public void dropCourse(Long enrollmentId) {
        Enrollment enrollment = enrollmentRepository.findById(enrollmentId).orElse(null);
        if (enrollment != null) {
            enrollment.setDroppedAt(LocalDateTime.now());
            enrollmentRepository.save(enrollment);
        }
    }
    public List<Enrollment> getEnrollmentsByStudentId(Long studentId) {
        return enrollmentRepository.findByStudentId(studentId);
    }
    public List<Enrollment> getActiveEnrollmentsByStudentId(Long studentId) {
        return enrollmentRepository.findByStudentIdAndDroppedAtIsNull(studentId);
    }
}