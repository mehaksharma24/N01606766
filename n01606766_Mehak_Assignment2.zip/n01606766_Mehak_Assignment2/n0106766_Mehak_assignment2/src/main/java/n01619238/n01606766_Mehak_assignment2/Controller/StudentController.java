package n01619238.n01619238_patel_assignment2.Controller;

import n01619238.n01619238_patel_assignment2.Model.Course;
import n01619238.n01619238_patel_assignment2.Model.Enrollment;
import n01619238.n01619238_patel_assignment2.Model.Student;
import n01619238.n01619238_patel_assignment2.Service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/student")
public class StudentController {
    @Autowired
    private StudentService studentService;

    @Autowired
    private CourseService courseService;

    @Autowired
    private EnrollmentService enrollmentService;

    // Dashboard - Show available courses (courses the student is not enrolled in)
    @GetMapping("/dashboard")
    public String studentDashboard(Model model, HttpSession session) {
        // Fetch the logged-in student's ID from the session
        Long loggedInUserId = (Long) session.getAttribute("loggedInUserId");
        if (loggedInUserId == null) {
            return "redirect:/login"; // Redirect to login if no user is logged in
        }

        // Fetch the logged-in student
        Student student = studentService.findByUserID(loggedInUserId);
        if (student == null) {
            return "redirect:/login"; // Redirect to login if student is not found
        }

        List<Course> allCourses = courseService.getAllCourses();
        List<Enrollment> activeEnrollments = enrollmentService.getActiveEnrollmentsByStudentId(student.getId());

        // Filter out courses the student is already enrolled in
        List<Course> availableCourses = allCourses.stream()
                .filter(course -> activeEnrollments.stream()
                        .noneMatch(enrollment -> enrollment.getCourse().getId().equals(course.getId())))
                .collect(Collectors.toList());

        model.addAttribute("student", student);
        model.addAttribute("availableCourses", availableCourses);
        return "student/dashboard";
    }

    // Show registered courses (active enrollments only)
    @GetMapping("/registered-courses")
    public String registeredCourses(Model model, HttpSession session) {
        // Fetch the logged-in student's ID from the session
        Long loggedInUserId = (Long) session.getAttribute("loggedInUserId");
        if (loggedInUserId == null) {
            return "redirect:/login"; // Redirect to login if no user is logged in
        }

        // Fetch the logged-in student
        Student student = studentService.findByUserID(loggedInUserId);
        if (student == null) {
            return "redirect:/login"; // Redirect to login if student is not found
        }

        // Fetch active enrollments (where droppedAt is null)
        List<Enrollment> activeEnrollments = enrollmentService.getActiveEnrollmentsByStudentId(student.getId());

        model.addAttribute("student", student);
        model.addAttribute("enrollments", activeEnrollments);
        return "student/register-course";
    }

    // Enroll in a course
    @PostMapping("/enroll-course/{courseId}")
    public String enrollCourse(@PathVariable Long courseId, RedirectAttributes redirectAttributes, HttpSession session) {
        // Fetch the logged-in student's ID from the session
        Long loggedInUserId = (Long) session.getAttribute("loggedInUserId");
        if (loggedInUserId == null) {
            return "redirect:/login"; // Redirect to login if no user is logged in
        }

        // Fetch the logged-in student
        Student student = studentService.findByUserID(loggedInUserId);
        if (student == null) {
            return "redirect:/login"; // Redirect to login if student is not found
        }

        Enrollment enrollment = enrollmentService.enrollStudent(student.getId(), courseId);

        if (enrollment != null) {
            redirectAttributes.addFlashAttribute("successMessage", "Enrolled in course: " + enrollment.getCourse().getName());
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Failed to enroll in the course.");
        }

        return "redirect:/student/dashboard";
    }

    // Drop a course (soft delete)
    @PostMapping("/drop-course/{enrollmentId}")
    public String dropCourse(@PathVariable Long enrollmentId, RedirectAttributes redirectAttributes, HttpSession session) {
        enrollmentService.dropCourse(enrollmentId);
        redirectAttributes.addFlashAttribute("successMessage", "Course dropped successfully.");
        return "redirect:/student/dashboard";
    }

    @GetMapping("/profile")
    public String showProfile(Model model, HttpSession session) {
        Long loggedInUserId = (Long) session.getAttribute("loggedInUserId");
        if (loggedInUserId == null) {
            return "redirect:/login"; // Redirect to login if no user is logged in
        }

        // Fetch the logged-in student
        Student student = studentService.findByUserID(loggedInUserId);
        if (student == null) {
            return "redirect:/login";
        }

        model.addAttribute("student", student);
        return "student/profile"; // Thymeleaf template for profile
    }

    // Update Profile
    @PostMapping("/profile/update")
    public String updateProfile(@ModelAttribute Student student, HttpSession session, RedirectAttributes redirectAttributes) {
        Long loggedInUserId = (Long) session.getAttribute("loggedInUserId");
        if (loggedInUserId == null) {
            return "redirect:/login";
        }

        // Fetch the existing student details
        Student existingStudent = studentService.findByUserID(loggedInUserId);
        if (existingStudent == null) {
            return "redirect:/login";
        }

        // Update fields
        existingStudent.setName(student.getName());
        existingStudent.setEmail(student.getEmail());
//        existingStudent.setAddress(student.getAddress());

        studentService.updateStudent(existingStudent);
        redirectAttributes.addFlashAttribute("successMessage", "Profile updated successfully!");

        return "redirect:/student/profile";
    }
}