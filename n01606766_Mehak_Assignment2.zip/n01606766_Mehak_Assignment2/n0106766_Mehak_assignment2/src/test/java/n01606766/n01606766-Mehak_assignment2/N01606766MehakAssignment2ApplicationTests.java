package n01619238.n01619238_patel_assignment2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class N01619238PatelAssignment2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
