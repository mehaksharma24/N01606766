package com.humber.n01606766_mehak.service;


import com.humber.n01606766_mehak.entity.Student;
import java.util.List;

public interface StudentService {
    List<Student> getAllStudents();
    void addStudent(Student student);
}
