package com.humber.n01606766_mehak.service;

import com.humber.n01606766_mehak.entity.Student;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class StudentServiceImpl implements StudentService {
    private final Map<Integer, Student> studentMap = new HashMap<>();

    public StudentServiceImpl() {
        studentMap.put(1, new Student(1, "Mehak", 24, "Female", "mehak@example.com", "Toronto", "1999-04-15"));
        studentMap.put(2, new Student(2, "Karan", 25, "Male", "karan@example.com", "Chennai", "1998-03-11"));
        studentMap.put(3, new Student(3, "Sneha", 23, "Female", "sneha@example.com", "Hyderabad", "2000-07-05"));
    }


    @Override
    public List<Student> getAllStudents() {
        return new ArrayList<>(studentMap.values());
    }

    @Override
    public void addStudent(Student student) {
        studentMap.put(student.getId(), student);
    }
}
