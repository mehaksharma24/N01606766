package com.humber.n01606766_mehak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class n01606766_mehak {

    public static void main(String[] args) {
        SpringApplication.run(n01606766_mehak.class, args);
    }

}
