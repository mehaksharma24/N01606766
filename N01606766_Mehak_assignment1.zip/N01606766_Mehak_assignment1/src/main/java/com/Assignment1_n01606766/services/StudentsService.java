package com.Assignment1_n01606766.services;

import com.Assignment1_n01606766.entities.Students;
import java.util.Map;

public interface StudentsService {
    void addStudent(Students student);
    Map<Integer, Students> getAllStudents();
    Students getStudentById(int id);
    void updateStudent(Students student);
    void deleteStudent(int id);
}