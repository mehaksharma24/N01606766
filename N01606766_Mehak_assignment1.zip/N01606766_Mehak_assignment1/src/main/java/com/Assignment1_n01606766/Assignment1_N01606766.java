package com.Assignment1_n01606766;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment1_N01606766 {

    public static void main(String[] args) {
        SpringApplication.run(Assignment1_N01606766.class, args);
    }

}
